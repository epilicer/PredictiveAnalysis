"""
Thin Python wrapper around EasyJet_FRAMModel.dll using ctypes.

This module:
- Loads the DLL (stdcall) on Windows.
- Calls Generate(json, out count) → pointer to a native struct.
- Marshals the struct fields:
    * ScoreCount (int)
    * FRAMScores (pointer to array of PWideChar)
    * ErrorNumber (int)
    * ErrorDescription (PWideChar)
- Frees unmanaged memory via FreeResponse(ptr).
- Provides helpers to convert a CSV (columns) into the JSON payload.

Requirements:
- Windows
- Matching architecture (x64 Python with x64 DLL, or x86 with x86)
- pandas (for CSV loading)
"""

from __future__ import annotations

import os
import json
import ctypes
from typing import Any, Optional, Tuple

import pandas as pd

# DLL Path
# DLL_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\General - FRAM v2\FRAMv2.2 SSG Delivery (Non COM)\FRAM 2.2 DLL\EasyJet_FRAMModel.dll"
DLL_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\Documents\workdir\csharp\FRAMv2.2 SSG Delivery (Non COM)\FRAM 2.2 Code\FRAMModel\bin\Debug\net8.0-windows\FRAMModel.dll"

# Sample CSV roster data
CSV_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\Documents\workdir\python\fram-v2\input\FILES\FRAM v.2\147_FramInput.Net.csv"

"""
IdxInBlock OperationalSectorCount IsaHomeStandbyFlag StartDateLocalTime StartTimeLocalTime EndDateLocalTime EndTimeLocalTime EndDateCrewReferenceTime EndTimeCrewReferenceTime   StartDateTimeZulu     EndDateTimeZulu DutyLength IsDutyMorningStart IsDutyEveningFinish IsDutyNightFinish IsDutyElongated IsDutyHighSector HoursBetweenMidnight IsStandby IsContactable CommuteTime
         1                      2                  0         03/05/2022           06:10:00       03/05/2022         14:21:00               03/05/2022                 14:21:00 03/05/2022 05:10:00 03/05/2022 13:21:00   08:11:00                  1                   0                 0               0                0             14:21:00     FALSE         FALSE    00:50:00
         2                      4                  0         04/05/2022           05:00:00       04/05/2022         13:25:00               04/05/2022                 13:25:00 04/05/2022 04:00:00 04/05/2022 12:25:00   08:25:00                  1                   0                 0               0                1             13:25:00     FALSE         FALSE    00:50:00
         3                      2                  0         05/05/2022           04:55:00       05/05/2022         12:56:00               05/05/2022                 12:56:00 05/05/2022 03:55:00 05/05/2022 11:56:00   08:01:00                  1                   0                 0               0                0             12:56:00     FALSE         FALSE    00:50:00
         1                      2                  0         17/05/2022           06:20:00       17/05/2022         12:52:00               17/05/2022                 12:52:00 17/05/2022 05:20:00 17/05/2022 11:52:00   06:32:00                  1                   0                 0               0                0             12:52:00     FALSE         FALSE    00:50:00
         2                      2                  0         18/05/2022           05:20:00       18/05/2022         11:51:00               18/05/2022                 11:51:00 18/05/2022 04:20:00 18/05/2022 10:51:00   06:31:00                  1                   0                 0               0                0             11:51:00     FALSE         FALSE    00:50:00
         1                      4                  0         21/05/2022           06:00:00       21/05/2022         16:28:00               21/05/2022                 16:28:00 21/05/2022 05:00:00 21/05/2022 15:28:00   10:28:00                  1                   0                 0               1                1             16:28:00     FALSE         FALSE    00:50:00
"""

# List all fields your FRMModelRequest expects
REQUIRED_FIELDS = [
    "IdxInBlock",
    "OperationalSectorCount",
    "IsaHomeStandbyFlag",
    "StartDateLocalTime",
    "StartTimeLocalTime",
    "EndDateLocalTime",
    "EndTimeLocalTime",
    "EndDateCrewReferenceTime",
    "EndTimeCrewReferenceTime",
    "StartDateTimeZulu",
    "EndDateTimeZulu",
    "DutyLength",
    "IsDutyMorningStart",
    "IsDutyEveningFinish",
    "IsDutyNightFinish",
    "IsDutyElongated",
    "IsDutyHighSector",
    "HoursBetweenMidnight",
    "IsContactable",
    "IsStandby",
    "CommuteTime",
]

class FRMModelNativeResponse(ctypes.Structure):
    """
    Native struct returned by the DLL's Generate function.

    Layout must match exactly the unmanaged memory layout returned by the DLL:
        typedef struct {
            int         ScoreCount;
            void*       FRAMScores;        // pointer to array of PWideChar (UTF-16)
            int         ErrorNumber;
            wchar_t*    ErrorDescription;  // PWideChar (UTF-16)
        } FRMModelNativeResponse;
    """
    _fields_ = [
        ("ScoreCount", ctypes.c_int),
        ("FRAMScores", ctypes.c_void_p),         # pointer to array of PWideChar
        ("ErrorNumber", ctypes.c_int),
        ("ErrorDescription", ctypes.c_wchar_p),  # PWideChar (UTF-16)
    ]

PFRMModelNativeResponse = ctypes.POINTER(FRMModelNativeResponse)

def load_library(dll_path: str) -> Tuple[ctypes.WinDLL, Optional[object]]:
    """
    Load the EasyJet_FRAMModel DLL with stdcall convention.

    On Python 3.8+ for Windows, adds the DLL directory so side-by-side native
    dependencies can be resolved.

    Args:
        dll_path: Absolute path to EasyJet_FRAMModel.dll.

    Returns:
        A tuple of (loaded WinDLL instance, add_dll_directory context or None).
        Keep the context object alive while the DLL is in use if needed.
    """
    dll_dir = os.path.dirname(dll_path)
    ctx: Optional[object] = None

    # Helps Python 3.8+ find side-by-side native deps
    if hasattr(os, "add_dll_directory"):
        ctx = os.add_dll_directory(dll_dir)

    lib = ctypes.WinDLL(dll_path)  # stdcall
    return lib, ctx

def get_functions(lib: ctypes.WinDLL) -> Tuple[Any, Any]:
    """
    Resolve and type the Generate and FreeResponse functions from the DLL.

    Signatures assumed (stdcall):
        PFRMModelNativeResponse Generate(wchar_t* json, int* outScoreCount);
        void FreeResponse(PFRMModelNativeResponse p);

    Args:
        lib: Loaded ctypes.WinDLL instance.

    Returns:
        (Generate, FreeResponse) function pointers with arg/restype configured.
    """
    Generate = lib.Generate
    Generate.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    Generate.restype = PFRMModelNativeResponse

    FreeResponse = lib.FreeResponse
    FreeResponse.argtypes = [PFRMModelNativeResponse]
    FreeResponse.restype = None

    return Generate, FreeResponse

def run_fram_model(json_payload: dict, dll_path: str = DLL_PATH) -> dict:
    """
    Call the DLL's Generate function with a JSON payload and return parsed results.

    This function:
      * Serializes the payload to UTF-16 wide string (via Python str),
      * Calls Generate(json, out count) to get a pointer to a native response,
      * Marshals the response struct and reads the FRAM scores,
      * Frees the unmanaged memory by calling FreeResponse.

    Args:
        json_payload:
            Either a dict/list (will be json.dumps'ed), or a raw JSON string.
        dll_path:
            Path to the EasyJet_FRAMModel.dll (defaults to DLL_PATH).

    Returns:
        FramModelResult dict with counts, score strings, and any error info.

    Raises:
        RuntimeError: If the DLL returns NULL (e.g., failure in Generate).
    """
    json_str = (
        json.dumps(json_payload, ensure_ascii=False)
        if isinstance(json_payload, (dict, list))
        else str(json_payload)
    )

    lib, _ = load_library(dll_path)
    Generate, FreeResponse = get_functions(lib)

    out_count = ctypes.c_int(0)
    resp_ptr = Generate(json_str, ctypes.byref(out_count))
    if not resp_ptr:
        raise RuntimeError("Generate returned NULL (failed to retrieve data).")

    try:
        native = resp_ptr.contents
        count_struct = int(native.ScoreCount)
        count_param = int(out_count.value)

        scores = []
        if count_struct > 0 and native.FRAMScores:
            # native.FRAMScores is a pointer to an array of PWideChar
            arr = ctypes.cast(native.FRAMScores, ctypes.POINTER(ctypes.c_wchar_p))  # type: ignore[attr-defined]
            scores = [arr[i] for i in range(count_struct)]
        else:
            # Fallback cast using the pointer on the instance, if class attr above not used
            arr = ctypes.cast(native.FRAMScores, ctypes.POINTER(ctypes.c_wchar_p))
            scores = [arr[i] for i in range(count_struct)]

        return {
            "score_count_param": count_param,
            "score_count_struct": count_struct,
            "scores": scores,
            "error_number": int(native.ErrorNumber),
            "error_description": native.ErrorDescription or "",
        }
    finally:
        # Always free unmanaged memory allocated in the DLL
        FreeResponse(resp_ptr)

def dataframe_to_request(df: pd.DataFrame) -> dict:
    """
    Convert a CSV-loaded DataFrame into the FRMModelRequest payload dict.

    The model expects an object whose keys are the required field names and whose
    values are arrays (one per duty/row). This function:
      * Preserves original string formatting (dates/times/booleans as strings),
      * Supplies empty arrays for any required fields that are missing in the CSV.

    Args:
        df: Input DataFrame loaded from the CSV (recommended dtype=str).

    Returns:
        A dict with keys from REQUIRED_FIELDS and list-of-string values.
    """
    payload = {}
    for col in REQUIRED_FIELDS:
        if col in df.columns:
            # Keep the original formatting; the model already handles these string forms
            payload[col] = df[col].astype(str).tolist()
        else:
            payload[col] = []
    return payload

def main(csv_path: str) -> None:
    """
    Load CSV, build request payload, call the DLL, and print results.

    Args:
        csv_path: Path to an input CSV file containing the FRAM input columns.
    """
    df = pd.read_csv(csv_path, dtype=str, encoding="utf-8-sig")
    payload = dataframe_to_request(df)

    result = run_fram_model(payload, DLL_PATH)
    print("ScoreCount (out param):", result["score_count_param"])
    print("ScoreCount (struct):   ", result["score_count_struct"])
    print("Scores:                ", result["scores"])
    print("ErrorNumber:           ", result["error_number"])
    print("ErrorDescription:      ", result["error_description"])

if __name__ == "__main__":
    main(CSV_PATH)
