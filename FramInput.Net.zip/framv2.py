# Aim: Consume FRAM dll to be used under Python

# -------------------------------------------------------------------------------------------
# Option 1:
# C:\Users\ErcanP\OneDrive - easyJet\General - FRAM v2\FRAMv2.2 SSG Delivery (Non COM)\Instructions.docx
# 1) .NET Code
# -------------------------------------------------------------------------------------------

import os
import json
import ctypes
from ctypes import wintypes

# DLL Path
DLL_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\General - FRAM v2\FRAMv2.2 SSG Delivery (Non COM)\FRAM 2.2 DLL\EasyJet_FRAMModel.dll"

# Native struct layout (must match what the DLL returns)
class FRMModelNativeResponse(ctypes.Structure):
    _fields_ = [
        ("ScoreCount", ctypes.c_int),
        ("FRAMScores", ctypes.c_void_p),        # pointer to array of PWideChar
        ("ErrorNumber", ctypes.c_int),
        ("ErrorDescription", ctypes.c_wchar_p), # PWideChar
    ]

PFRMModelNativeResponse = ctypes.POINTER(FRMModelNativeResponse)

"""
  dll_path = DLL_PATH

  dll_dir = os.path.dirname(dll_path)
  # Ensure dependent DLLs in the same folder are found (Python 3.8+)
  ctx = None
  if hasattr(os, "add_dll_directory"):
      ctx = os.add_dll_directory(dll_dir)
  lib = ctypes.WinDLL(dll_path)  # stdcall calling convention
  # return lib, ctx

  # PFRMModelNativeResponse Generate(wchar_t* json, int* outScoreCount) stdcall
  Generate = lib.Generate
  Generate.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
  Generate.restype  = PFRMModelNativeResponse

  # void FreeResponse(PFRMModelNativeResponse) stdcall
  FreeResponse = lib.FreeResponse
  FreeResponse.argtypes = [PFRMModelNativeResponse]
  FreeResponse.restype  = None
  # return Generate, FreeResponse

  json_input = {
      "IdxInBlock":[1,2,3,4,5,1,2],
      "OperationalSectorCount":[2,2,2,4,2,2,2],
      "IsaHomeStandbyFlag":[0,0,0,0,0,0,0],
      "StartDateLocalTime":["19/09/2016","20/09/2016","21/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
      "StartTimeLocalTime":["15:15:00","15:30:00","15:55:00","14:00:00","11:50:00","6:45:00","5:35:00"],
      "EndDateLocalTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
      "EndTimeLocalTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","17:10:00","12:36:00"],
      "EndDateCrewReferenceTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
      "EndTimeCrewReferenceTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","12:36:00"],
      "StartDateTimeZulu":["19/09/2016 16:15","20/09/2016 16:30","21/09/2016 16:55","22/09/2016 15:00","23/09/2016 12:50","28/09/2016 07:45","29/09/2016 06:35"],
      "EndDateTimeZulu":["19/09/2016 23:15","21/09/2016 01:21","22/09/2016 01:30","23/09/2016 00:29","23/09/2016 22:12","28/09/2016 18:10","29/09/2016 13:36"],
      "DutyLength":["7:00:00","8:51:00","8:35:00","9:29:00","9:22:00","10:25:00","7:01:00"],
      "IsDutyMorningStart":[0,0,0,0,0,1,1],
      "IsDutyEveningFinish":[1,1,1,1,1,0,0],
      "IsDutyNightFinish":[0,0,0,0,0,0,0],
      "IsDutyElongated":[0,0,0,0,0,1,0],
      "IsDutyHighSector":[0,0,0,1,0,0,0],
      "HoursBetweenMidnight":["23:15:00","25:21:00","25:30:00","25:29:00","22:12:00","18:10:00","13:36:00"],
      "IsContactable":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],
      "IsStandby":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],
      "CommuteTime":["0:50","0:50","0:50","0:50","0:50","0:50","0:50"]
  }

  json_payload = json_input

  # Accept dict or str
  if isinstance(json_payload, (dict, list)):
      json_str = json.dumps(json_payload, ensure_ascii=False)
  else:
      json_str = str(json_payload)

  # lib, _ = load_library(dll_path)
  # Generate, FreeResponse = get_functions(lib)

  out_count = ctypes.c_int(0)
  resp_ptr = Generate(json_str, ctypes.byref(out_count))
  if not resp_ptr:
      raise RuntimeError("Generate returned NULL (failed to retrieve data).")

  native = resp_ptr.contents

  # Prefer struct’s count (should match the out param)
  count_struct = int(native.ScoreCount)
  count_param  = int(out_count.value)

  # Read array of PWideChar at FRAMScores
  scores = []
  if count_struct > 0 and native.FRAMScores:
      # Treat FRAMScores as pointer to array of PWideChar
      arr = ctypes.cast(native.FRAMScores, ctypes.POINTER(ctypes.c_wchar_p))
      scores = [arr[i] for i in range(count_struct)]

  error_number = int(native.ErrorNumber)
  error_description = native.ErrorDescription or ""
"""

# Load library and set prototypes (stdcall)
def load_library(dll_path: str):
    dll_dir = os.path.dirname(dll_path)
    # Ensure dependent DLLs in the same folder are found (Python 3.8+)
    ctx = None
    if hasattr(os, "add_dll_directory"):
        ctx = os.add_dll_directory(dll_dir)
    lib = ctypes.WinDLL(dll_path)  # stdcall calling convention
    return lib, ctx

def get_functions(lib):
    # PFRMModelNativeResponse Generate(wchar_t* json, int* outScoreCount) stdcall
    Generate = lib.Generate
    Generate.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    Generate.restype  = PFRMModelNativeResponse

    # void FreeResponse(PFRMModelNativeResponse) stdcall
    FreeResponse = lib.FreeResponse
    FreeResponse.argtypes = [PFRMModelNativeResponse]
    FreeResponse.restype  = None

    return Generate, FreeResponse

# Call helper
def run_fram_model(json_payload, dll_path=DLL_PATH):
    # Accept dict or str
    if isinstance(json_payload, (dict, list)):
        json_str = json.dumps(json_payload, ensure_ascii=False)
    else:
        json_str = str(json_payload)

    lib, _ = load_library(dll_path)
    Generate, FreeResponse = get_functions(lib)

    out_count = ctypes.c_int(0)
    resp_ptr = Generate(json_str, ctypes.byref(out_count))
    if not resp_ptr:
        raise RuntimeError("Generate returned NULL (failed to retrieve data).")

    try:
        native = resp_ptr.contents

        # Prefer struct’s count (should match the out param)
        count_struct = int(native.ScoreCount)
        count_param  = int(out_count.value)

        # Read array of PWideChar at FRAMScores
        scores = []
        if count_struct > 0 and native.FRAMScores:
            # Treat FRAMScores as pointer to array of PWideChar
            arr = ctypes.cast(native.FRAMScores, ctypes.POINTER(ctypes.c_wchar_p))
            scores = [arr[i] for i in range(count_struct)]

        error_number = int(native.ErrorNumber)
        error_description = native.ErrorDescription or ""

        return {
            "score_count_param": count_param,
            "score_count_struct": count_struct,
            "scores": scores,
            "error_number": error_number,
            "error_description": error_description,
        }
    finally:
        # Always free unmanaged memory allocated by the DLL
        FreeResponse(resp_ptr)


# Example usage with your payload
def main_option1():
    json_input = {
        "IdxInBlock":[1,2,3,4,5,1,2],
        "OperationalSectorCount":[2,2,2,4,2,2,2],
        "IsaHomeStandbyFlag":[0,0,0,0,0,0,0],
        "StartDateLocalTime":["19/09/2016","20/09/2016","21/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
        "StartTimeLocalTime":["15:15:00","15:30:00","15:55:00","14:00:00","11:50:00","6:45:00","5:35:00"],
        "EndDateLocalTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
        "EndTimeLocalTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","17:10:00","12:36:00"],
        "EndDateCrewReferenceTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
        "EndTimeCrewReferenceTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","12:36:00"],
        "StartDateTimeZulu":["19/09/2016 16:15","20/09/2016 16:30","21/09/2016 16:55","22/09/2016 15:00","23/09/2016 12:50","28/09/2016 07:45","29/09/2016 06:35"],
        "EndDateTimeZulu":["19/09/2016 23:15","21/09/2016 01:21","22/09/2016 01:30","23/09/2016 00:29","23/09/2016 22:12","28/09/2016 18:10","29/09/2016 13:36"],
        "DutyLength":["7:00:00","8:51:00","8:35:00","9:29:00","9:22:00","10:25:00","7:01:00"],
        "IsDutyMorningStart":[0,0,0,0,0,1,1],
        "IsDutyEveningFinish":[1,1,1,1,1,0,0],
        "IsDutyNightFinish":[0,0,0,0,0,0,0],
        "IsDutyElongated":[0,0,0,0,0,1,0],
        "IsDutyHighSector":[0,0,0,1,0,0,0],
        "HoursBetweenMidnight":["23:15:00","25:21:00","25:30:00","25:29:00","22:12:00","18:10:00","13:36:00"],
        "IsContactable":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],
        "IsStandby":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],
        "CommuteTime":["0:50","0:50","0:50","0:50","0:50","0:50","0:50"]
    }

    result = run_fram_model(json_input, DLL_PATH)
    print("ScoreCount (out param):", result["score_count_param"])
    print("ScoreCount (struct):   ", result["score_count_struct"])
    print("Scores:                ", result["scores"])
    print("ErrorNumber:           ", result["error_number"])
    print("ErrorDescription:      ", result["error_description"])

# if __name__ == "__main__":
#     main_option1()

# -------------------------------------------------------------------------------------------
# Option 2:
# C:\Users\ErcanP\OneDrive - easyJet\General - FRAM v2\FRAMv2.2 SSG Delivery (Non COM)\Instructions.docx
# 2) Delphi
# -------------------------------------------------------------------------------------------

import os
import ctypes
from ctypes import wintypes

# DLL Path
DLL_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\General - FRAM v2\FRAMv2.2 SSG Delivery (Non COM)\FRAM 2.2 DLL\EasyJet_FRAMModel.dll"

# Structure equivalent to Delphi's TResponseNative
class TResponseNative(ctypes.Structure):
    _fields_ = [
        ("ScoreCount", ctypes.c_int),
        ("Scores", ctypes.c_void_p),            # pointer to array of PWideChar
        ("ErrorNumber", ctypes.c_int),
        ("ErrorDescription", ctypes.c_wchar_p), # PWideChar
    ]

PResponseNative = ctypes.POINTER(TResponseNative)

def load_library(dll_path: str):
    dll_dir = os.path.dirname(dll_path)
    # For Python 3.8+ on Windows, ensure the loader can find the DLL and its deps
    add_dir_ctx = None
    if hasattr(os, "add_dll_directory"):
        add_dir_ctx = os.add_dll_directory(dll_dir)
    try:
        lib = ctypes.WinDLL(dll_path)  # stdcall
    finally:
        # The context should stay alive if needed, so don't close it too early.
        pass
    return lib, add_dir_ctx

def get_functions(lib):
    # Prototype: PResponseNative Generate(wchar_t* json, int* outScoreCount) stdcall
    Generate = lib.Generate
    Generate.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    Generate.restype  = PResponseNative

    # Prototype: void FreeResponse(PResponseNative) stdcall
    FreeResponse = lib.FreeResponse
    FreeResponse.argtypes = [PResponseNative]
    FreeResponse.restype  = None

    return Generate, FreeResponse

def call_generate(json_str: str, dll_path: str):
    lib, ctx = load_library(dll_path)
    Generate, FreeResponse = get_functions(lib)

    out_count = ctypes.c_int(0)
    resp_ptr = Generate(json_str, ctypes.byref(out_count))

    if not resp_ptr:
        raise RuntimeError("Generate returned NULL (failed to retrieve data).")

    try:
        resp = resp_ptr.contents
        # Prefer the count from struct; should match out_count.value
        count = int(resp.ScoreCount)

        # Interpret Scores as array of PWideChar (wchar_t*)
        scores_list = []
        if count > 0 and resp.Scores:
            PWideChar = ctypes.c_wchar_p
            array_type = ctypes.POINTER(PWideChar)
            scores_array = ctypes.cast(resp.Scores, array_type)

            for i in range(count):
                s = scores_array[i]           # This yields a Python str (from wchar*)
                scores_list.append(s)

        error_number = int(resp.ErrorNumber)
        error_description = resp.ErrorDescription or ""

        return {
            "score_count_param": int(out_count.value),  # from the out parameter
            "score_count_struct": count,                 # from the struct
            "scores": scores_list,
            "error_number": error_number,
            "error_description": error_description,
        }
    finally:
        # Always free memory allocated by the DLL
        FreeResponse(resp_ptr)
        # If you created an add_dll_directory context, keep it alive for the lifetime
        # of the loaded DLL or explicitly close it when you're done with all calls.

def main_option2():
    json_input = (
        '{"IdxInBlock":[1,2,3,4,5,1,2],'
        '"OperationalSectorCount":[2,2,2,4,2,2,2],'
        '"IsaHomeStandbyFlag":[0,0,0,0,0,0,0],'
        '"StartDateLocalTime":["19/09/2016","20/09/2016","21/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],'
        '"StartTimeLocalTime":["15:15:00","15:30:00","15:55:00","14:00:00","11:50:00","6:45:00","5:35:00"],'
        '"EndDateLocalTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],'
        '"EndTimeLocalTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","17:10:00","12:36:00"],'
        '"EndDateCrewReferenceTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],'
        '"EndTimeCrewReferenceTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","12:36:00"],'
        '"StartDateTimeZulu":["19/09/2016 16:15","20/09/2016 16:30","21/09/2016 16:55","22/09/2016 15:00","23/09/2016 12:50","28/09/2016 07:45","29/09/2016 06:35"],'
        '"EndDateTimeZulu":["19/09/2016 23:15","21/09/2016 01:21","22/09/2016 01:30","23/09/2016 00:29","23/09/2016 22:12","28/09/2016 18:10","29/09/2016 13:36"],'
        '"DutyLength":["7:00:00","8:51:00","8:35:00","9:29:00","9:22:00","10:25:00","7:01:00"],'
        '"IsDutyMorningStart":[0,0,0,0,0,1,1],'
        '"IsDutyEveningFinish":[1,1,1,1,1,0,0],'
        '"IsDutyNightFinish":[0,0,0,0,0,0,0],'
        '"IsDutyElongated":[0,0,0,0,0,1,0],'
        '"IsDutyHighSector":[0,0,0,1,0,0,0],'
        '"HoursBetweenMidnight":["23:15:00","25:21:00","25:30:00","25:29:00","22:12:00","18:10:00","13:36:00"],'
        '"IsContactable":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],'
        '"IsStandby":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],'
        '"CommuteTime":["0:50","0:50","0:50","0:50","0:50","0:50","0:50"]}'
    )

    result = call_generate(json_input, DLL_PATH)
    print("ScoreCount (out param):", result["score_count_param"])
    print("ScoreCount (struct):   ", result["score_count_struct"])
    print("Scores:                ", result["scores"])
    print("ErrorNumber:           ", result["error_number"])
    print("ErrorDescription:      ", result["error_description"])

# if __name__ == "__main__":
#     main_option2()

# -------------------------------------------------------------------------------------------
# Option 3:
# Read DLL and JsonString to consume FRAM
# -------------------------------------------------------------------------------------------

import sys, os, json
import clr  # provided by pythonnet 2.x

# Add the folder containing Model.dll and its dependencies
# sys.path.append(r"C:\path\to\your\bin")  # adjust to your path

# DLL Path
DLL_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\General - FRAM v2\FRAMv2.2 SSG Delivery (Non COM)\FRAM 2.2 DLL\EasyJet_FRAMModel.dll"

# Either reference by file path or by assembly name if it's in probing path/GAC
clr.AddReference(DLL_PATH)

# Now import types from your assembly's namespace
# from ModelNamespace import Calculator  # adjust to your real namespace/class
from EasyJet.FRAMModel.Engine import ScoreGenerator

# Your JSON input (string)
json_input = """{
  "IdxInBlock":[1,2,3,4,5,1,2],
  "OperationalSectorCount":[2,2,2,4,2,2,2],
  "IsaHomeStandbyFlag":[0,0,0,0,0,0,0],
  "StartDateLocalTime":["19/09/2016","20/09/2016","21/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
  "StartTimeLocalTime":["15:15:00","15:30:00","15:55:00","14:00:00","11:50:00","6:45:00","5:35:00"],
  "EndDateLocalTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
  "EndTimeLocalTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","17:10:00","12:36:00"],
  "EndDateCrewReferenceTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],
  "EndTimeCrewReferenceTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","17:10:00","12:36:00"],
  "StartDateTimeZulu":["19/09/2016 16:15","20/09/2016 16:30","21/09/2016 16:55","22/09/2016 15:00","23/09/2016 12:50","28/09/2016 07:45","29/09/2016 06:35"],
  "EndDateTimeZulu":["19/09/2016 23:15","21/09/2016 01:21","22/09/2016 01:30","23/09/2016 00:29","23/09/2016 22:12","28/09/2016 18:10","29/09/2016 13:36"],
  "DutyLength":["7:00:00","8:51:00","8:35:00","9:29:00","9:22:00","10:25:00","7:01:00"],
  "IsDutyMorningStart":[0,0,0,0,0,1,1],
  "IsDutyEveningFinish":[1,1,1,1,1,0,0],
  "IsDutyNightFinish":[0,0,0,0,0,0,0],
  "IsDutyElongated":[0,0,0,0,0,1,0],
  "IsDutyHighSector":[0,0,0,1,0,0,0],
  "HoursBetweenMidnight":["23:15:00","25:21:00","25:30:00","25:29:00","22:12:00","18:10:00","13:36:00"],
  "IsContactable":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],
  "IsStandby":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],
  "CommuteTime":["0:50","0:50","0:50","0:50","0:50","0:50","0:50"]
}"""

# Suppose your DLL exposes a static method like:
# public static string Evaluate(string jsonInput)
result_json = Calculator.Evaluate(json_input)

# Convert back to Python object if it returns JSON
result = json.loads(str(result_json))
print(result)

# -------------------------------------------------------------------------------------------
# Option 4:
# 
# -------------------------------------------------------------------------------------------

import sys, os
import pythonnet
pythonnet.load("coreclr")  # if targeting .NET 6/7/8
import clr
from ctypes import Structure, c_int, c_void_p, c_wchar_p, POINTER, cast

# Map the native struct
class FRMModelNativeResponse(Structure):
    _fields_ = [
        ("ScoreCount", c_int),
        ("FRAMScores", c_void_p),
        ("ErrorNumber", c_int),
        ("ErrorDescription", c_wchar_p),
    ]
PResp = POINTER(FRMModelNativeResponse)

DLL_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\General - FRAM v2\FRAMv2.2 SSG Delivery (Non COM)\FRAM 2.2 DLL\EasyJet_FRAMModel.dll"

# Load managed assembly
# sys.path.append(r"C:\path\to\bin")
clr.AddReference(DLL_PATH)

from EasyJet.FRAMModel.Engine import ScoreGenerator
from System import Int32

json_input = (
    '{"IdxInBlock":[1,2,3,4,5,1,2],'
    '"OperationalSectorCount":[2,2,2,4,2,2,2],'
    '"IsaHomeStandbyFlag":[0,0,0,0,0,0,0],'
    '"StartDateLocalTime":["19/09/2016","20/09/2016","21/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],'
    '"StartTimeLocalTime":["15:15:00","15:30:00","15:55:00","14:00:00","11:50:00","6:45:00","5:35:00"],'
    '"EndDateLocalTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],'
    '"EndTimeLocalTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","17:10:00","12:36:00"],'
    '"EndDateCrewReferenceTime":["19/09/2016","21/09/2016","22/09/2016","22/09/2016","23/09/2016","28/09/2016","29/09/2016"],'
    '"EndTimeCrewReferenceTime":["22:15:00","0:21:00","0:30:00","23:29:00","21:12:00","12:36:00"],'
    '"StartDateTimeZulu":["19/09/2016 16:15","20/09/2016 16:30","21/09/2016 16:55","22/09/2016 15:00","23/09/2016 12:50","28/09/2016 07:45","29/09/2016 06:35"],'
    '"EndDateTimeZulu":["19/09/2016 23:15","21/09/2016 01:21","22/09/2016 01:30","23/09/2016 00:29","23/09/2016 22:12","28/09/2016 18:10","29/09/2016 13:36"],'
    '"DutyLength":["7:00:00","8:51:00","8:35:00","9:29:00","9:22:00","10:25:00","7:01:00"],'
    '"IsDutyMorningStart":[0,0,0,0,0,1,1],'
    '"IsDutyEveningFinish":[1,1,1,1,1,0,0],'
    '"IsDutyNightFinish":[0,0,0,0,0,0,0],'
    '"IsDutyElongated":[0,0,0,0,0,1,0],'
    '"IsDutyHighSector":[0,0,0,1,0,0,0],'
    '"HoursBetweenMidnight":["23:15:00","25:21:00","25:30:00","25:29:00","22:12:00","18:10:00","13:36:00"],'
    '"IsContactable":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],'
    '"IsStandby":["FALSE","FALSE","FALSE","FALSE","FALSE","FALSE","FALSE"],'
    '"CommuteTime":["0:50","0:50","0:50","0:50","0:50","0:50","0:50"]}'
)

count = Int32(0)
json_str = json_input
ptr = ScoreGenerator.Generate(json_str, count)

try:
    resp_ptr = cast(ptr.ToInt64(), PResp)
    resp = resp_ptr.contents
    arr = cast(resp.FRAMScores, ctypes.POINTER(ctypes.c_wchar_p))
    scores = [arr[i] for i in range(resp.ScoreCount)]
finally:



# -------------------------------------------------------------------------------------------
# Option 5:
# 
# -------------------------------------------------------------------------------------------

import os, json, ctypes
import pandas as pd

# DLL Path
DLL_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\General - FRAM v2\FRAMv2.2 SSG Delivery (Non COM)\FRAM 2.2 DLL\EasyJet_FRAMModel.dll"

# Sample csv data
CSV_PATH = r"C:\Users\ErcanP\OneDrive - easyJet\Documents\workdir\python\fram-v2\input\FILES\FRAM v.2\147_FramInput.Net.csv"

import os, json, ctypes
import pandas as pd

# DLL Path
DLL_PATH = r"C:\Users\ErcanP\EasyJet_FRAMModel.dll"

# Sample csv data
CSV_PATH = r"C:\Users\ErcanP\147_FramInput.Net.csv"

# List all fields your FRMModelRequest expects (adjust after you share function 2)
REQUIRED_FIELDS = [
    "IdxInBlock",
    "OperationalSectorCount",
    "IsaHomeStandbyFlag",
    "StartDateLocalTime",
    "StartTimeLocalTime",
    "EndDateLocalTime",
    "EndTimeLocalTime",
    "EndDateCrewReferenceTime",
    "EndTimeCrewReferenceTime",
    "StartDateTimeZulu",
    "EndDateTimeZulu",
    "DutyLength",
    "IsDutyMorningStart",
    "IsDutyEveningFinish",
    "IsDutyNightFinish",
    "IsDutyElongated",
    "IsDutyHighSector",
    "HoursBetweenMidnight",
    "IsContactable",
    "IsStandby",
    "CommuteTime",
]

# Struct returned by Generate (order/layout must match native code)
class FRMModelNativeResponse(ctypes.Structure):
    _fields_ = [
        ("ScoreCount", ctypes.c_int),
        ("FRAMScores", ctypes.c_void_p),        # pointer to array of PWideChar
        ("ErrorNumber", ctypes.c_int),
        ("ErrorDescription", ctypes.c_wchar_p), # PWideChar (UTF-16)
    ]

PFRMModelNativeResponse = ctypes.POINTER(FRMModelNativeResponse)

def _load_library(dll_path: str):
  dll_dir = os.path.dirname(dll_path)
  ctx = None
  # Helps Python 3.8+ find side-by-side native deps
  if hasattr(os, "add_dll_directory"):
      ctx = os.add_dll_directory(dll_dir)
  lib = ctypes.WinDLL(dll_path)  # stdcall
  return lib, ctx

def _get_functions(lib):
  Generate = lib.Generate
  Generate.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
  Generate.restype  = PFRMModelNativeResponse
  FreeResponse = lib.FreeResponse
  FreeResponse.argtypes = [PFRMModelNativeResponse]
  FreeResponse.restype  = None
  return Generate, FreeResponse

def run_fram_model(json_payload, dll_path: str=DLL_PATH):
    """Accepts dict/list or JSON string. Returns scores and error info."""
    json_str = json.dumps(json_payload, ensure_ascii=False) if isinstance(json_payload, (dict, list)) else str(json_payload)

    lib, _ = _load_library(dll_path)
    Generate, FreeResponse = _get_functions(lib)

    out_count = ctypes.c_int(0)
    resp_ptr = Generate(json_str, ctypes.byref(out_count))
    if not resp_ptr:
        raise RuntimeError("Generate returned NULL (failed to retrieve data).")

    try:
        native = resp_ptr.contents
        count_struct = int(native.ScoreCount)
        count_param  = int(out_count.value)

        scores = []
        if count_struct > 0 and native.FRAMScores:
            arr = ctypes.cast(native.FRAMScores, ctypes.POINTER(ctypes.c_wchar_p))
            scores = [arr[i] for i in range(count_struct)]

        return {
            "score_count_param": count_param,
            "score_count_struct": count_struct,
            "scores": scores,
            "error_number": int(native.ErrorNumber),
            "error_description": native.ErrorDescription or "",
        }
    finally:
        # Free unmanaged memory allocated in the DLL
        FreeResponse(resp_ptr)

def dataframe_to_request(df: pd.DataFrame) -> dict:
    """
    Build the JSON-ready dict with array fields, matching FRMModelRequest.
    Leaves values as strings if they come as strings (like your CSV).
    """
    payload = {}
    for col in REQUIRED_FIELDS:
        if col in df.columns:
            # Keep the original formatting; the model already handles these string forms
            payload[col] = df[col].astype(str).tolist()
        else:
            payload[col] = []
    return payload

def main(csv_path: str):

    df = pd.read_csv(csv_path, dtype=str, encoding="utf-8-sig")
    payload = dataframe_to_request(df)

    result = run_fram_model(payload, DLL_PATH)
    print("ScoreCount (out param):", result["score_count_param"])
    print("ScoreCount (struct):   ", result["score_count_struct"])
    print("Scores:                ", result["scores"])
    print("ErrorNumber:           ", result["error_number"])
    print("ErrorDescription:      ", result["error_description"])

if __name__ == "__main__":
    main(CSV_PATH)
