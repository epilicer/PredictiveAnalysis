﻿using System.Collections.Generic;


namespace EasyJet.FRAMModel.Engine.Entities
{
  internal class DutyBlockScore
  {
    public List<DutyPeriodScore> DutyPeriodScoreList { get; set; }
  }
}
