﻿using System.Collections.Generic;


namespace EasyJet.FRAMModel.Engine.Entities
{
  internal class ScoreList
  {
    public List<DutyBlockScore> DutyBlockScoreList { get; set; }
  }
}
