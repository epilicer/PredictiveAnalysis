﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyJet.FRAMModel.SleepWake.Entities
{
    internal class InitialDatetimeWithNapEntity
    {
        public DateTime beginDateInitial { get; set; }
        public double[] hnap { get; set; }
        public double[] cnap { get; set; }
    }
}
