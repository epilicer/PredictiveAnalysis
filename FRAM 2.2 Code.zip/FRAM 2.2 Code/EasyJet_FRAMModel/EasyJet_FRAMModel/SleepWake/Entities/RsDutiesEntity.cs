﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyJet.FRAMModel.SleepWake.Entities
{
    internal class RsDutiesEntity
    {
        public double StartPhase { get; set; }
        public double EndPhase { get; set; }
        public double StartCircadian { get; set; }
        public double StartHomeostatic { get; set; }
        public double StartAlertness { get; set; }
        public double EndCircadian { get; set; }
        public double EndHomeostatic { get; set; }
        public double EndAlertness { get; set; }
    }
}
