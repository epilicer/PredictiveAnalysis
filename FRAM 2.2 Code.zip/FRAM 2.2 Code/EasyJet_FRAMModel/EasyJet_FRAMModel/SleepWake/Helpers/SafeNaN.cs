﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace EasyJet.FRAMModel.SleepWake.Helpers
{
    public static class SafeNaN
    {
        public static readonly double GetSafeNaN = BitConverter.Int64BitsToDouble(0x7ff8000000000000);
        //[MethodImpl(MethodImplOptions.NoInlining)]
        //public static double GetSafeNaN()
        //{
        //    return BitConverter.Int64BitsToDouble(0x7ff8000000000000);
        //}
    }
}
