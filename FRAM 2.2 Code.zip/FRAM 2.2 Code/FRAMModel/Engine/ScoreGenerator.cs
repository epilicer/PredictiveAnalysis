﻿using EasyJet.FRAMModel.Engine.Calculator;
using EasyJet.FRAMModel.Engine.Exceptions;
using EasyJet.FRAMModel.Engine.ExternalContract;
using EasyJet.FRAMModel.SleepWake.Calculator;
using EasyJet.FRAMModel.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Json;
using System.Text;

namespace EasyJet.FRAMModel.Engine
{
    public class ScoreGenerator
    {
        
        // [DllExport("Generate", CallingConvention = CallingConvention.StdCall)]
        public static IntPtr Generate([MarshalAs(UnmanagedType.LPWStr)] string requestJson, out int scoreCount)
        {
            IFRMModelResponse frmModelResponse = (IFRMModelResponse)new FRMModelResponse();
            FRMModelNativeResponse native = new FRMModelNativeResponse();
            scoreCount = 0;
            try
            {
                var serializer = new DataContractJsonSerializer(typeof(FRMModelRequest));
                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(requestJson)))
                {
                    FRMModelRequest request = (FRMModelRequest)serializer.ReadObject(ms);
                    EntityMapper entityMapper = new EntityMapper();
                    frmModelResponse = entityMapper.GetScoreArray(new ScoreCalculator().Calculate(entityMapper.GetDutyBlockList(request)));
                    List<int> idxMask = entityMapper.idxMask;

                    ProcessSleepWake processData = new ProcessSleepWake();
                    frmModelResponse.FRMScore = processData.Calculate(request, frmModelResponse.FRMScore, idxMask);
                    scoreCount = frmModelResponse.FRMScore.Length;
                    IntPtr[] scorePtrs = new IntPtr[scoreCount];

                    for (int i = 0; i < scoreCount; i++)
                        scorePtrs[i] = Marshal.StringToHGlobalUni(frmModelResponse.FRMScore[i]);

                    IntPtr scoresPtr = Marshal.AllocHGlobal(IntPtr.Size * scoreCount);
                    Marshal.Copy(scorePtrs, 0, scoresPtr, scoreCount);
                    native.ScoreCount = scoreCount;
                    native.FRAMScores = scoresPtr;

                }
            }
            catch (ArgumentNullException ex)
            {
                frmModelResponse.ErrorNumber = 1001;
                frmModelResponse.ErrorDescription = ex.ParamName;
                frmModelResponse.FRMScore = (string[])null;
            }
            catch (InvalidDataValueException ex)
            {
                frmModelResponse.ErrorNumber = ex.ErrorNumber;
                frmModelResponse.ErrorDescription = "InvalidDataValueException for parameter " + ex.FieldName + " at Index " + (object)ex.Index + " contains Value " + ex.FieldValue;
                frmModelResponse.FRMScore = (string[])null;
            }
            catch (InvalidDataFormatException ex)
            {
                frmModelResponse.ErrorNumber = ex.ErrorNumber;
                frmModelResponse.ErrorDescription = ex.Message;
                frmModelResponse.FRMScore = (string[])null;
            }
            catch (Exception ex)
            {
                frmModelResponse.ErrorNumber = 1004;
                frmModelResponse.ErrorDescription = ex.Message;
                frmModelResponse.FRMScore = (string[])null;
            }


            native.ErrorNumber = frmModelResponse.ErrorNumber;
            native.ErrorDescription = Marshal.StringToHGlobalUni(frmModelResponse.ErrorDescription);

            // Allocate unmanaged struct
            IntPtr responsePtr = Marshal.AllocHGlobal(Marshal.SizeOf<FRMModelNativeResponse>());
            Marshal.StructureToPtr(native, responsePtr, false);

            return responsePtr;
        }

        // [DllExport("FreeResponse", CallingConvention = CallingConvention.StdCall)]
        public static void FreeResponse(IntPtr ptr)
        {
            if (ptr == IntPtr.Zero) return;

            var native = Marshal.PtrToStructure<FRMModelNativeResponse>(ptr);

            // Free strings in Score[]
            for (int i = 0; i < native.ScoreCount; i++)
            {
                IntPtr pStr = Marshal.ReadIntPtr(native.FRAMScores, i * IntPtr.Size);
                if (pStr != IntPtr.Zero)
                    Marshal.FreeHGlobal(pStr);
            }

            if (native.FRAMScores != IntPtr.Zero)
                Marshal.FreeHGlobal(native.FRAMScores);

            if (native.ErrorDescription != IntPtr.Zero)
                Marshal.FreeHGlobal(native.ErrorDescription);

            Marshal.FreeHGlobal(ptr);
        }
    }
}
