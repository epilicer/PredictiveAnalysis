﻿
namespace EasyJet.FRAMModel.Engine.Entities
{
  internal class Stage1Response
  {
    public DutyBlock DutyBlock { get; set; }
  }
}
