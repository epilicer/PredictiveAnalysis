﻿using System;


namespace EasyJet.FRAMModel.Engine.Entities
{
  internal class DutyPeriodScore
  {
    public Decimal Score { get; set; }
  }
}
