﻿using System;
using System.Runtime.InteropServices;

//#nullable disable
namespace EasyJet.FRAMModel.Engine.ExternalContract
{    
    public class FRMModelResponse : IFRMModelResponse
    {

        public string[] FRMScore { get; set; }


        public int ErrorNumber { get; set; }


        public string ErrorDescription { get; set; }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct FRMModelNativeResponse
    {
        public int ScoreCount;

        public IntPtr FRAMScores; // pointer to array of pointers to strings

        public int ErrorNumber;

        public IntPtr ErrorDescription; // pointer to a single string
    }
}
