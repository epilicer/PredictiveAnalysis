﻿using System.Runtime.InteropServices;

//#nullable disable
namespace EasyJet.FRAMModel.Engine.ExternalContract
{  
  public interface IScoreGenerator
  {
    IFRMModelResponse Generate(IFRMModelRequest request);
  }
}
