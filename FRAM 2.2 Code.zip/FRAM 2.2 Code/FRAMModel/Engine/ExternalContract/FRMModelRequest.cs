﻿using System.Runtime.InteropServices;

//#nullable disable
namespace EasyJet.FRAMModel.Engine.ExternalContract
{

    /// <summary>
    /// Represents a request for FRM model.
    /// </summary>     
    public class FRMModelRequest : IFRMModelRequest
    {
        /// <summary>
        /// Gets or sets the index in block.
        /// </summary>
        public int[] IdxInBlock { get; set; }

        /// <summary>
        /// Gets or sets the operational sector count.
        /// </summary>
        public int[] OperationalSectorCount { get; set; }

        /// <summary>
        /// Gets or sets the ISA home standby flag.
        /// </summary>
        public int[] IsaHomeStandbyFlag { get; set; }

        /// <summary>
        /// Gets or sets the start date local time.
        /// </summary>
        public string[] StartDateLocalTime { get; set; }

        /// <summary>
        /// Gets or sets the start time local time.
        /// </summary>
        public string[] StartTimeLocalTime { get; set; }

        /// <summary>
        /// Gets or sets the end date local time.
        /// </summary>
        public string[] EndDateLocalTime { get; set; }

        /// <summary>
        /// Gets or sets the end time local time.
        /// </summary>
        public string[] EndTimeLocalTime { get; set; }

        /// <summary>
        /// Gets or sets the end date crew reference time.
        /// </summary>
        public string[] EndDateCrewReferenceTime { get; set; }

        /// <summary>
        /// Gets or sets the end time crew reference time.
        /// </summary>
        public string[] EndTimeCrewReferenceTime { get; set; }

        /// <summary>
        /// Gets or sets the start date time zulu.
        /// </summary>
        public string[] StartDateTimeZulu { get; set; }

        /// <summary>
        /// Gets or sets the end date time zulu.
        /// </summary>
        public string[] EndDateTimeZulu { get; set; }

        /// <summary>
        /// Gets or sets the duty length.
        /// </summary>
        public string[] DutyLength { get; set; }

        /// <summary>
        /// Gets or sets the is duty morning start.
        /// </summary>
        public int[] IsDutyMorningStart { get; set; }

        /// <summary>
        /// Gets or sets the is duty evening finish.
        /// </summary>
        public int[] IsDutyEveningFinish { get; set; }

        /// <summary>
        /// Gets or sets the is duty night finish.
        /// </summary>
        public int[] IsDutyNightFinish { get; set; }

        /// <summary>
        /// Gets or sets the is duty elongated.
        /// </summary>
        public int[] IsDutyElongated { get; set; }

        /// <summary>
        /// Gets or sets the is duty high sector.
        /// </summary>
        public int[] IsDutyHighSector { get; set; }

        /// <summary>
        /// Gets or sets the hours between midnight.
        /// </summary>
        public string[] HoursBetweenMidnight { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether each item is contactable.
        /// </summary>
        public string[] IsContactable { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether each item is on standby.
        /// </summary>
        public string[] IsStandby { get; set; }

        /// <summary>
        /// Gets or sets the commute time.
        /// </summary>
        public string[] CommuteTime { get; set; }
    }
}
