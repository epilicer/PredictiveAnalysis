﻿using System.Runtime.InteropServices;

//#nullable disable
namespace EasyJet.FRAMModel.Engine.ExternalContract
{  
  public interface IFRMModelResponse
  {
   
    string[] FRMScore { get; set; }

   
    int ErrorNumber { get; set; }

   
    string ErrorDescription { get; set; }
  }
}
