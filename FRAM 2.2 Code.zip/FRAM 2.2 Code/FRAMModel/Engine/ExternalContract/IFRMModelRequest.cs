﻿using System.Runtime.InteropServices;

//#nullable disable
namespace EasyJet.FRAMModel.Engine.ExternalContract
{

    /// <summary>
    /// Represents the contract for the FRM Model request.
    /// </summary>
    
    public interface IFRMModelRequest
    {
        /// <summary>
        /// Gets or sets the array of IdxInBlock values.
        /// </summary>
       
        int[] IdxInBlock { get; set; }

        /// <summary>
        /// Gets or sets the array of OperationalSectorCount values.
        /// </summary>
        
        int[] OperationalSectorCount { get; set; }

        /// <summary>
        /// Gets or sets the array of IsaHomeStandbyFlag values.
        /// </summary>
       
        int[] IsaHomeStandbyFlag { get; set; }

        /// <summary>
        /// Gets or sets the array of StartDateLocalTime values.
        /// </summary>
        
        string[] StartDateLocalTime { get; set; }

        /// <summary>
        /// Gets or sets the array of StartTimeLocalTime values.
        /// </summary>
        
        string[] StartTimeLocalTime { get; set; }

        /// <summary>
        /// Gets or sets the array of EndDateLocalTime values.
        /// </summary>
       
        string[] EndDateLocalTime { get; set; }

        /// <summary>
        /// Gets or sets the array of EndTimeLocalTime values.
        /// </summary>
       
        string[] EndTimeLocalTime { get; set; }

        /// <summary>
        /// Gets or sets the array of EndDateCrewReferenceTime values.
        /// </summary>
       
        string[] EndDateCrewReferenceTime { get; set; }

        /// <summary>
        /// Gets or sets the array of EndTimeCrewReferenceTime values.
        /// </summary>
        
        string[] EndTimeCrewReferenceTime { get; set; }

        /// <summary>
        /// Gets or sets the array of StartDateTimeZulu values.
        /// </summary>
       
        string[] StartDateTimeZulu { get; set; }

        /// <summary>
        /// Gets or sets the array of EndDateTimeZulu values.
        /// </summary>
        
        string[] EndDateTimeZulu { get; set; }

        /// <summary>
        /// Gets or sets the array of DutyLength values.
        /// </summary>
       
        string[] DutyLength { get; set; }

        /// <summary>
        /// Gets or sets the array of IsDutyMorningStart values.
        /// </summary>
       
        int[] IsDutyMorningStart { get; set; }

        /// <summary>
        /// Gets or sets the array of IsDutyEveningFinish values.
        /// </summary>
        
        int[] IsDutyEveningFinish { get; set; }

        /// <summary>
        /// Gets or sets the array of IsDutyNightFinish values.
        /// </summary>
       
        int[] IsDutyNightFinish { get; set; }

        /// <summary>
        /// Gets or sets the array of IsDutyElongated values.
        /// </summary>
       
        int[] IsDutyElongated { get; set; }

        /// <summary>
        /// Gets or sets the array of IsDutyHighSector values.
        /// </summary>
      
        int[] IsDutyHighSector { get; set; }

        /// <summary>
        /// Gets or sets the array of HoursBetweenMidnight values.
        /// </summary>
       
        string[] HoursBetweenMidnight { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether each item is contactable.
        /// </summary>
       
        string[] IsContactable { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether each item is on standby.
        /// </summary>
       
        string[] IsStandby { get; set; }

        /// <summary>
        /// Gets or sets the array of CommuteTime values.
        /// </summary>
        [DispId(21)]
        string[] CommuteTime { get; set; }
    }
}
