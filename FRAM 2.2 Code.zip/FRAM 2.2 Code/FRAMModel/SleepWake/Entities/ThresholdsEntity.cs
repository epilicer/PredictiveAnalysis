﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyJet.FRAMModel.SleepWake.Entities
{
    internal class ThresholdsEntity
    {
        public double Item1 { get; set; }
        public double Item2 { get; set; }
        public double Item3 { get; set; }
    }
}
