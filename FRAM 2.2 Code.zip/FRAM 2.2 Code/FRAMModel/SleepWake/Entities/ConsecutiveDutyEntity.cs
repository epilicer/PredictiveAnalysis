﻿using EasyJet.FRAMModel.SleepWake.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyJet.FRAMModel.SleepWake.Entities
{
    internal class ConsecutiveDutyEntity
    {
        public double[]  circadian { get; set;}
        public double[]  homeostatic { get; set;}
        public List<SleepEpisodeEntity> resultPhases { get; set;}
    }
}
