﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyJet.FRAMModel.SleepWake.Entities
{
    internal class ASleepEpisodeNumbaEntity
    {
        public bool IsAwake { get; set; }
        public double H { get; set; }
        public int IdxSleep { get; set; }
        public int IdxWake { get; set; }
    }
}
