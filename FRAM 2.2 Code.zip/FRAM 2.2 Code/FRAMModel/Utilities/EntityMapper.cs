﻿using EasyJet.FRAMModel.Engine.Entities;
using EasyJet.FRAMModel.Engine.Exceptions;
using EasyJet.FRAMModel.Engine.ExternalContract;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
// using System.Data.Linq;

//#nullable disable
namespace EasyJet.FRAMModel.Utilities
{
    internal class EntityMapper
    {
        TimeSpan MIN_REST_TIME = new TimeSpan(8, 0, 0);
        TimeSpan MIN_ONE_DAY_OFF = new TimeSpan(36, 0, 0);
        public List<int> idxMask;

        public List<DutyBlock> GetDutyBlockList(IFRMModelRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("Null request");
            if (((IEnumerable<object>)new object[21]
            {
        (object) request.IdxInBlock,
        (object) request.OperationalSectorCount,
        (object) request.IsaHomeStandbyFlag,
        (object) request.StartDateLocalTime,
        (object) request.StartTimeLocalTime,
        (object) request.EndDateLocalTime,
        (object) request.EndTimeLocalTime,
        (object) request.EndDateCrewReferenceTime,
        (object) request.EndTimeCrewReferenceTime,
        (object) request.StartDateTimeZulu,
        (object) request.EndDateTimeZulu,
        (object) request.DutyLength,
        (object) request.IsDutyMorningStart,
        (object) request.IsDutyEveningFinish,
        (object) request.IsDutyNightFinish,
        (object) request.IsDutyElongated,
        (object) request.IsDutyHighSector,
        (object) request.HoursBetweenMidnight,
        (object) request.IsStandby,
        (object) request.IsContactable,
        (object) request.CommuteTime
            }).Any<object>((Func<object, bool>)(x => x == null)))
                throw new ArgumentNullException("Null request parameter value");
            this.ValidateRequestFormat(request);
            this.ValidateRequestValues(request);
            this.PrepareData(request);
            return this.MapRequestValuesToDutyBlock(request);
        }

        public List<DutyBlock> MapRequestValuesToDutyBlock(IFRMModelRequest request)
        {
            List<DutyBlock> dutyBlock1 = new List<DutyBlock>();
            int num1 = 0;
            ArrayList filteredDutyBlockList = this.GetFilteredDutyBlockList(request);
            for (int index1 = 0; index1 < filteredDutyBlockList.Count; ++index1)
            {
                DutyBlock dutyBlock2 = new DutyBlock();
                List<DutyPeriod> dutyPeriodList = new List<DutyPeriod>();
                dutyBlock2.DutyBlockDutyCount = int.Parse(filteredDutyBlockList[index1].ToString());                
                int num2 = dutyBlock2.DutyBlockDutyCount + num1;
                for (int index2 = num1; index2 < num2; ++index2)
                {
                    dutyPeriodList.Add(new DutyPeriod()
                    {
                        DutyPeriodOfDutyBlock = request.IdxInBlock[index2],
                        OperationalSectorCount = request.OperationalSectorCount[index2],
                        IsaHomeStandbyFlag = Convert.ToBoolean(request.IsaHomeStandbyFlag[index2]),
                        StartDateLocalTime = Convert.ToDateTime(DateTime.Parse(request.StartDateLocalTime[index2], (IFormatProvider)new CultureInfo("en-GB"))),
                        StartTimeLocalTime = Convert.ToDateTime(DateTime.Parse(request.StartTimeLocalTime[index2], (IFormatProvider)new CultureInfo("en-GB"))).ToString("HH:mm"),
                        EndDateLocalTime = Convert.ToDateTime(DateTime.Parse(request.EndDateLocalTime[index2], (IFormatProvider)new CultureInfo("en-GB"))),
                        EndTimeLocalTime = Convert.ToDateTime(DateTime.Parse(request.EndTimeLocalTime[index2], (IFormatProvider)new CultureInfo("en-GB"))).ToString("HH:mm"),
                        EndDateCrewReferenceTime = Convert.ToDateTime(DateTime.Parse(request.EndDateCrewReferenceTime[index2], (IFormatProvider)new CultureInfo("en-GB"))),
                        EndTimeCrewReferenceTime = Convert.ToDateTime(DateTime.Parse(request.EndTimeCrewReferenceTime[index2], (IFormatProvider)new CultureInfo("en-GB"))).ToString("HH:mm"),
                        StartDateTimeZulu = Convert.ToDateTime(DateTime.Parse(request.StartDateTimeZulu[index2], (IFormatProvider)new CultureInfo("en-GB"))),
                        EndDateTimeZulu = Convert.ToDateTime(DateTime.Parse(request.EndDateTimeZulu[index2], (IFormatProvider)new CultureInfo("en-GB"))),
                        DutyLength = request.DutyLength[index2],
                        IsDutyMorningStart = Convert.ToBoolean(request.IsDutyMorningStart[index2]),
                        IsDutyEveningFinish = Convert.ToBoolean(request.IsDutyEveningFinish[index2]),
                        IsDutyNightFinish = Convert.ToBoolean(request.IsDutyNightFinish[index2]),
                        IsDutyElongated = Convert.ToBoolean(request.IsDutyElongated[index2]),
                        IsDutyHighSector = Convert.ToBoolean(request.IsDutyHighSector[index2]),
                        HoursBetweenMidnight = request.HoursBetweenMidnight[index2],
                    });
                    num1++;
                }
                dutyBlock2.DutyPeriods = (IList<DutyPeriod>)dutyPeriodList;
                dutyBlock1.Add(dutyBlock2);
            }
            return dutyBlock1;
        }

        public ArrayList GetFilteredDutyBlockList(IFRMModelRequest request)
        {
            ArrayList filteredDutyBlockList = new ArrayList();
            int length = request.IdxInBlock.Length;
            for (int index = 0; index < length; ++index)
            {
                int num = request.IdxInBlock[index];
                if (index == length - 1)
                    filteredDutyBlockList.Add((object)num);
                else if (request.IdxInBlock[index + 1] <= num)
                    filteredDutyBlockList.Add((object)num);
            }
            return filteredDutyBlockList;
        }

        private void ValidateRequestValues(IFRMModelRequest request)
        {
            string[] formats = new string[1] { "d/M/yyyy" };
            for (int index = 0; index < request.IdxInBlock.Length; ++index)
            {
                if (request.IdxInBlock[index] <= 0)
                    throw new InvalidDataValueException("IdxInBlock", index, request.IdxInBlock[index].ToString());
                if (request.OperationalSectorCount[index] < 0)
                    throw new InvalidDataValueException("OperationalSectorCount", index, request.OperationalSectorCount[index].ToString());
                if (request.IsaHomeStandbyFlag[index] != 0 && request.IsaHomeStandbyFlag[index] != 1)
                    throw new InvalidDataValueException("IsaHomeStandbyFlag", index, request.IsaHomeStandbyFlag[index].ToString());
                DateTime result;
                if (!DateTime.TryParseExact(request.StartDateLocalTime[index], formats, (IFormatProvider)new CultureInfo("en-GB"), DateTimeStyles.None, out result))
                    throw new InvalidDataValueException("StartDateLocalTime", index, request.StartDateLocalTime[index].ToString());
                if (!DateTime.TryParseExact(request.EndDateLocalTime[index], formats, (IFormatProvider)new CultureInfo("en-GB"), DateTimeStyles.None, out result))
                    throw new InvalidDataValueException("EndDateLocalTime", index, request.EndDateLocalTime[index].ToString());
                if (!DateTime.TryParseExact(request.EndDateCrewReferenceTime[index], formats, (IFormatProvider)new CultureInfo("en-GB"), DateTimeStyles.None, out result))
                    throw new InvalidDataValueException("EndDateCrewReferenceTime", index, request.EndDateCrewReferenceTime[index].ToString());
                if (request.IsDutyMorningStart[index] != 0 && request.IsDutyMorningStart[index] != 1)
                    throw new InvalidDataValueException("IsDutyMorningStart", index, request.IsDutyMorningStart[index].ToString());
                if (request.IsDutyEveningFinish[index] != 0 && request.IsDutyEveningFinish[index] != 1)
                    throw new InvalidDataValueException("IsDutyEveningFinish", index, request.IsDutyEveningFinish[index].ToString());
                if (request.IsDutyNightFinish[index] != 0 && request.IsDutyNightFinish[index] != 1)
                    throw new InvalidDataValueException("IsDutyNightFinish", index, request.IsDutyNightFinish[index].ToString());
                if (request.IsDutyElongated[index] != 0 && request.IsDutyElongated[index] != 1)
                    throw new InvalidDataValueException("IsDutyElongated", index, request.IsDutyElongated[index].ToString());
                if (request.IsDutyHighSector[index] != 0 && request.IsDutyHighSector[index] != 1)
                    throw new InvalidDataValueException("IsDutyHighSector", index, request.IsDutyHighSector[index].ToString());
            }
        }

        private void ValidateRequestFormat(IFRMModelRequest request)
        {
            if (!((IEnumerable<int>)new int[21]
            {
        request.IdxInBlock.Length,
        request.OperationalSectorCount.Length,
        request.IsaHomeStandbyFlag.Length,
        request.StartDateLocalTime.Length,
        request.StartTimeLocalTime.Length,
        request.EndDateLocalTime.Length,
        request.EndTimeLocalTime.Length,
        request.EndDateCrewReferenceTime.Length,
        request.EndTimeCrewReferenceTime.Length,
        request.StartDateTimeZulu.Length,
        request.EndDateTimeZulu.Length,
        request.DutyLength.Length,
        request.IsDutyMorningStart.Length,
        request.IsDutyEveningFinish.Length,
        request.IsDutyNightFinish.Length,
        request.IsDutyElongated.Length,
        request.IsDutyHighSector.Length,
        request.HoursBetweenMidnight.Length,
        request.IsContactable.Length,
        request.IsStandby.Length,
        request.CommuteTime.Length
            }).All<int>((Func<int, bool>)(x => x == request.IdxInBlock.Length)))
                throw new InvalidDataFormatException("Mismatch of duty periods count");
        }

        public IFRMModelResponse GetScoreArray(ScoreList scoreList)
        {
            if (scoreList == null)
                throw new ArgumentNullException("FRAM Score is null");
            List<string> stringList = new List<string>();
            foreach (DutyBlockScore dutyBlockScore in scoreList.DutyBlockScoreList)
            {
                foreach (DutyPeriodScore dutyPeriodScore in dutyBlockScore.DutyPeriodScoreList)
                    stringList.Add(dutyPeriodScore.Score.ToString());
            }
            FRMModelResponse scoreArray = new FRMModelResponse();
            scoreArray.FRMScore = stringList.ToArray();
            return (IFRMModelResponse)scoreArray;
        }

        public void PrepareData(IFRMModelRequest request)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("RowIndex", typeof(int));
            dt.Columns.Add("OperationalSectorCount", typeof(int));
            dt.Columns.Add("IsaHomeStandbyFlag", typeof(int));
            dt.Columns.Add("StartDateLocalTime", typeof(string));
            dt.Columns.Add("StartTimeLocalTime", typeof(string));
            dt.Columns.Add("EndDateLocalTime", typeof(string));
            dt.Columns.Add("EndTimeLocalTime", typeof(string));
            dt.Columns.Add("EndDateCrewReferenceTime", typeof(string));
            dt.Columns.Add("EndTimeCrewReferenceTime", typeof(string));
            dt.Columns.Add("StartDateTimeZulu", typeof(string));
            dt.Columns.Add("EndDateTimeZulu", typeof(string));
            dt.Columns.Add("DutyLength", typeof(string));
            dt.Columns.Add("IsDutyMorningStart", typeof(int));
            dt.Columns.Add("IsDutyEveningFinish", typeof(int));
            dt.Columns.Add("IsDutyNightFinish", typeof(int));
            dt.Columns.Add("IsDutyElongated", typeof(int));
            dt.Columns.Add("IsDutyHighSector", typeof(int));
            dt.Columns.Add("HoursBetweenMidnight", typeof(string));
            dt.Columns.Add("IsContactable", typeof(string));
            dt.Columns.Add("IsStandby", typeof(string));
            dt.Columns.Add("CommuteTime", typeof(string));
            dt.Columns.Add("RestTime", typeof(TimeSpan));
            dt.Columns.Add("BlockIDWL", typeof(int));
            dt.Columns.Add("DayInBlockWL", typeof(int));
            dt.Columns.Add("DutyEnd", typeof(DateTime));
            dt.Columns.Add("DutyBegin", typeof(DateTime));

            for (int i = 0; i < request.IdxInBlock.Length; i++)
            {
                dt.Rows.Add();
                DataRow dataRow = dt.Rows[dt.Rows.Count - 1];
                dataRow["RowIndex"] = i + 1;
                dataRow["OperationalSectorCount"] = request.OperationalSectorCount[i];
                dataRow["IsaHomeStandbyFlag"] = request.IsaHomeStandbyFlag[i];
                dataRow["StartDateLocalTime"] = request.StartDateLocalTime[i];
                dataRow["StartTimeLocalTime"] = request.StartTimeLocalTime[i];
                dataRow["EndDateLocalTime"] = request.EndDateLocalTime[i];
                dataRow["EndTimeLocalTime"] = request.EndTimeLocalTime[i];
                dataRow["EndDateCrewReferenceTime"] = request.EndDateCrewReferenceTime[i];
                dataRow["EndTimeCrewReferenceTime"] = request.EndTimeCrewReferenceTime[i];
                dataRow["StartDateTimeZulu"] = request.StartDateTimeZulu[i];
                dataRow["EndDateTimeZulu"] = request.EndDateTimeZulu[i];
                dataRow["DutyLength"] = request.DutyLength[i];
                dataRow["IsDutyMorningStart"] = request.IsDutyMorningStart[i];
                dataRow["IsDutyEveningFinish"] = request.IsDutyEveningFinish[i];
                dataRow["IsDutyNightFinish"] = request.IsDutyNightFinish[i];
                dataRow["IsDutyElongated"] = request.IsDutyElongated[i];
                dataRow["IsDutyHighSector"] = request.IsDutyHighSector[i];
                dataRow["HoursBetweenMidnight"] = request.HoursBetweenMidnight[i];
                dataRow["IsContactable"] = request.IsContactable[i];
                dataRow["IsStandby"] = request.IsStandby[i];
                dataRow["CommuteTime"] = request.CommuteTime[i];
            }
            var sortedRows = dt.AsEnumerable()
                            .OrderBy(row => Convert.ToDateTime(DateTime.Parse(row.Field<string>("StartDateLocalTime"), (IFormatProvider)new CultureInfo("en-GB"))))
                            .ThenBy(row => Convert.ToDateTime(DateTime.Parse(row.Field<string>("StartTimeLocalTime"), (IFormatProvider)new CultureInfo("en-GB"))).TimeOfDay)
                            .CopyToDataTable();
            foreach (DataRow row in dt.Rows)
            {
                DateTime dutyBegin = Convert.ToDateTime(DateTime.Parse(row["StartDateLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB")))
                                   .Add(Convert.ToDateTime(DateTime.Parse(row["StartTimeLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB"))).TimeOfDay);
                row["DutyBegin"] = dutyBegin;
                DateTime dutyEnd = Convert.ToDateTime(DateTime.Parse(row["EndDateLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB")))
                                   .Add(Convert.ToDateTime(DateTime.Parse(row["EndTimeLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB"))).TimeOfDay);
                row["DutyEnd"] = dutyEnd;                
            }            

            // Calculate RestTime as the difference between the next DutyBegin and current DutyEnd           
            for (int i = 0; i < dt.Rows.Count - 1; i++)
            {
                DateTime currentDutyEnd = DateTime.Parse(dt.Rows[i]["DutyEnd"].ToString());
                DateTime nextDutyBegin = DateTime.Parse(dt.Rows[i + 1]["DutyBegin"].ToString());
                dt.Rows[i]["RestTime"] = nextDutyBegin - currentDutyEnd;
            }

            dt.Rows[dt.Rows.Count - 1]["RestTime"] = DBNull.Value;

            idxMask = dt.AsEnumerable().
                Where(row => row["RestTime"] != DBNull.Value && !string.IsNullOrEmpty(row["RestTime"].ToString()) &&
                row.Field<TimeSpan>("RestTime") < MIN_REST_TIME)
                      .Select(row => dt.Rows.IndexOf(row))
                      .ToList();
            if (idxMask != null && idxMask.Count > 0)
            {
                idxMask.Sort((a, b) => b.CompareTo(a));
                // Process rows with insufficient rest time
                foreach (var idx in idxMask)
                {
                    dt = MergeRows(dt, idx);
                }

                for (int i = 0; i < dt.Rows.Count - 1; i++)
                {
                    DateTime currentEnd = Convert.ToDateTime(DateTime.Parse(dt.Rows[i]["EndDateLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB")));
                    DateTime nextStart = Convert.ToDateTime(DateTime.Parse(dt.Rows[i + 1]["StartDateLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB")));
                    dt.Rows[i]["RestTime"] = nextStart - currentEnd;
                }

                // Set the 'RestTime' for the last row
                if (dt.Rows.Count > 0)
                {
                    dt.Rows[dt.Rows.Count - 1]["RestTime"] = MIN_ONE_DAY_OFF;
                }

                int blockIDSW = 1;
                dt.Rows[0]["BlockIDWL"] = blockIDSW;
                for (int i = 1; i < dt.Rows.Count; i++)
                {
                    DateTime currentStartDate = Convert.ToDateTime(DateTime.Parse(dt.Rows[i]["StartDateLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB")));
                    DateTime previousStartDate = Convert.ToDateTime(DateTime.Parse(dt.Rows[i - 1]["StartDateLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB")));

                    if ((currentStartDate - previousStartDate).TotalDays > 1)
                    {
                        blockIDSW++;
                    }
                    dt.Rows[i]["BlockIDWL"] = blockIDSW;
                }

                // Calculate DayInBlockSW
                foreach (var group in dt.AsEnumerable().GroupBy(row => row.Field<int>("BlockIDWL")))
                {
                    int dayInBlock = 1;
                    foreach (var row in group)
                    {
                        row.SetField("DayInBlockWL", dayInBlock++);
                    }
                }
                EnumerableRowCollection<DataRow> rc = dt.AsEnumerable();//.Select(row => row.Field<int>("RowIndex")).ToList();

                request.IdxInBlock = rc.Select(row => row.Field<int>("DayInBlockWL")).ToArray();
                request.OperationalSectorCount = rc.Select(row => row.Field<int>("OperationalSectorCount")).ToArray();
                request.IsaHomeStandbyFlag = rc.Select(row => row.Field<int>("IsaHomeStandbyFlag")).ToArray();
                request.StartDateLocalTime = rc.Select(row => row.Field<string>("StartDateLocalTime")).ToArray();
                request.StartTimeLocalTime = rc.Select(row => row.Field<string>("StartTimeLocalTime")).ToArray();
                request.EndDateLocalTime = rc.Select(row => row.Field<string>("EndDateLocalTime")).ToArray();
                request.EndTimeLocalTime = rc.Select(row => row.Field<string>("EndTimeLocalTime")).ToArray();
                request.EndDateCrewReferenceTime = rc.Select(row => row.Field<string>("EndDateCrewReferenceTime")).ToArray();
                request.EndTimeCrewReferenceTime = rc.Select(row => row.Field<string>("EndTimeCrewReferenceTime")).ToArray();
                request.StartDateTimeZulu = rc.Select(row => row.Field<string>("StartDateTimeZulu")).ToArray();
                request.EndDateTimeZulu = rc.Select(row => row.Field<string>("EndDateTimeZulu")).ToArray();
                request.DutyLength = rc.Select(row => row.Field<string>("DutyLength")).ToArray();
                request.IsDutyMorningStart = rc.Select(row => row.Field<int>("IsDutyMorningStart")).ToArray();
                request.IsDutyEveningFinish = rc.Select(row => row.Field<int>("IsDutyEveningFinish")).ToArray();
                request.IsDutyNightFinish = rc.Select(row => row.Field<int>("IsDutyNightFinish")).ToArray();
                request.IsDutyElongated = rc.Select(row => row.Field<int>("IsDutyElongated")).ToArray();
                request.IsDutyHighSector = rc.Select(row => row.Field<int>("IsDutyHighSector")).ToArray();
                request.HoursBetweenMidnight = rc.Select(row => row.Field<string>("HoursBetweenMidnight")).ToArray();
                request.IsContactable = rc.Select(row => row.Field<string>("IsContactable")).ToArray();
                request.IsStandby = rc.Select(row => row.Field<string>("IsStandby")).ToArray();
                request.CommuteTime = rc.Select(row => row.Field<string>("CommuteTime")).ToArray();
            }
        }

        public DataTable MergeRows(DataTable dt, int idx)
        {  
            // Merging columns
            dt.Rows[idx]["OperationalSectorCount"] = Convert.ToInt32(dt.Rows[idx]["OperationalSectorCount"]) + Convert.ToInt32(dt.Rows[idx + 1]["OperationalSectorCount"]);
            dt.Rows[idx]["IsaHomeStandbyFlag"] = Math.Max(Convert.ToInt32(dt.Rows[idx]["IsaHomeStandbyFlag"]), Convert.ToInt32(dt.Rows[idx + 1]["IsaHomeStandbyFlag"]));
            dt.Rows[idx]["EndDateLocalTime"] = dt.Rows[idx + 1]["EndDateLocalTime"];
            dt.Rows[idx]["EndTimeLocalTime"] = dt.Rows[idx + 1]["EndTimeLocalTime"];
            dt.Rows[idx]["EndDateCrewReferenceTime"] = dt.Rows[idx + 1]["EndDateCrewReferenceTime"];
            dt.Rows[idx]["EndTimeCrewReferenceTime"] = dt.Rows[idx + 1]["EndTimeCrewReferenceTime"];
            dt.Rows[idx]["EndDatetimeZulu"] = dt.Rows[idx + 1]["EndDatetimeZulu"];

            // Calculating duty period
            DateTime startDate = Convert.ToDateTime(DateTime.Parse(dt.Rows[idx]["StartDatetimeZulu"].ToString(), (IFormatProvider)new CultureInfo("en-GB")));
            DateTime endDate = Convert.ToDateTime(DateTime.Parse(dt.Rows[idx + 1]["EndDatetimeZulu"].ToString(), (IFormatProvider)new CultureInfo("en-GB")));
            TimeSpan dutyPeriod = endDate - startDate;

            int h = (int)dutyPeriod.TotalHours;
            int m = (int)(dutyPeriod.TotalMinutes % 60);
            int d = h / 24;
            dt.Rows[idx]["DutyLength"] = $"{(d * 24 + h):D2}:{m:D2}:00";

            dt.Rows[idx]["IsDutyMorningStart"] = Math.Max(Convert.ToInt32(dt.Rows[idx]["IsDutyMorningStart"]), Convert.ToInt32(dt.Rows[idx + 1]["IsDutyMorningStart"]));
            dt.Rows[idx]["IsDutyEveningFinish"] = Math.Max(Convert.ToInt32(dt.Rows[idx]["IsDutyEveningFinish"]), Convert.ToInt32(dt.Rows[idx + 1]["IsDutyEveningFinish"]));
            dt.Rows[idx]["IsDutyNightFinish"] = Math.Max(Convert.ToInt32(dt.Rows[idx]["IsDutyNightFinish"]), Convert.ToInt32(dt.Rows[idx + 1]["IsDutyNightFinish"]));

            dt.Rows[idx]["IsDutyElongated"] = dutyPeriod > TimeSpan.FromHours(10) ? 1 : 0;
            dt.Rows[idx]["IsDutyHighSector"] = Convert.ToInt32(dt.Rows[idx]["OperationalSectorCount"]) > 3 ? 1 : 0;

            // Calculating hours between midnight
            DateTime startLocal = Convert.ToDateTime(DateTime.Parse(dt.Rows[idx]["StartDateLocalTime"].ToString() + " " + dt.Rows[idx]["StartTimeLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB")));
            DateTime endLocal = Convert.ToDateTime(DateTime.Parse(dt.Rows[idx + 1]["EndDateLocalTime"].ToString()+ " "+ dt.Rows[idx + 1]["EndTimeLocalTime"].ToString(), (IFormatProvider)new CultureInfo("en-GB")));
            TimeSpan hoursBetweenMidnight = HoursBetweenMidnight(startLocal, endLocal);

            h = (int)hoursBetweenMidnight.TotalHours;
            m = (int)(hoursBetweenMidnight.TotalMinutes % 60);
            d = h / 24;
            dt.Rows[idx]["HoursBetweenMidnight"] = $"{(d * 24 + h):D2}:{m:D2}:00";

            dt.Rows[idx]["IsStandby"] = (Convert.ToBoolean(dt.Rows[idx]["IsStandby"]) || Convert.ToBoolean(dt.Rows[idx + 1]["IsStandby"])).ToString().ToUpper();
            dt.Rows[idx]["IsContactable"] = (Convert.ToBoolean(dt.Rows[idx]["IsContactable"]) || Convert.ToBoolean(dt.Rows[idx + 1]["IsContactable"])).ToString().ToUpper();
            
            dt.Rows[idx]["CommuteTime"] = TimeSpan.Parse(dt.Rows[idx]["CommuteTime"].ToString()) > TimeSpan.Parse(dt.Rows[idx+1]["CommuteTime"].ToString())
                                  ? dt.Rows[idx]["CommuteTime"]
                                  : dt.Rows[idx+1]["CommuteTime"];
            // Removing the merged row
            dt.Rows.RemoveAt(idx + 1);
            return dt;
        }        

        public TimeSpan HoursBetweenMidnight(DateTime startDt, DateTime endDt)
        {
            if (startDt == DateTime.MinValue || endDt == DateTime.MinValue)
            {
                // return null if invalid date values (equivalent to NaT in pandas)
                return new TimeSpan();
            }
            else
            {
                int days = (endDt.Date - startDt.Date).Days;
                int hours = endDt.Hour;
                int minutes = endDt.Minute;
                return new TimeSpan(days, hours, minutes, 0);
            }
        }
    }
}
